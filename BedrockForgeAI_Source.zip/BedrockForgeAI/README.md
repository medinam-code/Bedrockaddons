# Bedrock Forge AI

Aplicación Android open source para crear proyectos de Add-Ons de Minecraft Bedrock sin registro ni inicio de sesión.

## Estado de esta entrega
MVP de código fuente. Incluye generador local de paquetes de recursos/comportamiento, validación estructural de JSON y manifiestos, editor JSON, exportación `.mcpack`/`.mcaddon` mediante el selector de archivos de Android y opción de endpoint de IA compatible configurable.

**No se afirma que esta versión ya haya sido compilada o probada dentro de Minecraft.** Para comprobar compatibilidad real del contenido, prueba los paquetes en la versión exacta del juego.

## Requisitos
- Android Studio reciente.
- JDK 17.
- Android SDK Platform 35.
- Gradle 8.9 o compatible con Android Gradle Plugin 8.7.3.

Abre la carpeta `BedrockForgeAI` en Android Studio y sincroniza Gradle. No se incluye el binario `gradle-wrapper.jar`; Android Studio puede abrir y compilar el proyecto usando su instalación de Gradle.

## Funciones incluidas
- Proyecto Resource Pack, Behavior Pack o Add-On combinado.
- UUIDs nuevos para encabezados y módulos.
- `manifest.json` con formato 2.
- Plantillas iniciales seguras y mínimas.
- Editor de JSON para el manifiesto del proyecto.
- Editor de textura píxel-art 16×16 con paleta básica y guardado PNG en el Resource Pack.
- Validación de JSON, UUIDs, módulos, archivos requeridos y versiones mínimas.
- Exportación ZIP compatible con `.mcpack` y `.mcaddon`.
- Modo local sin cuenta.
- Configuración opcional de endpoint de chat completions; no incluye API key ni proveedor por defecto.

## IA por internet sin cuenta propia
La app no exige crear una cuenta. Para IA remota, el usuario debe configurar un endpoint público compatible que permita solicitudes sin autenticación. La disponibilidad y privacidad dependen de ese proveedor. No se envía ningún dato hasta que el usuario pulse “Consultar IA”.

## Licencia
MIT. Consulta `LICENSE`.

## Limitaciones conocidas del MVP
- El generador crea esqueletos de paquetes, no garantiza que una entidad compleja sea jugable sin completar sus archivos de cliente, geometría, texturas y comportamiento.
- El editor de textura es básico (16×16 y paleta limitada); la generación avanzada de entidades queda para una siguiente iteración.
- La validación de versiones es orientativa: Bedrock no ofrece un único número de versión que garantice compatibilidad con todos los componentes.
- La importación automática en Minecraft depende de las asociaciones de archivos configuradas en Android. La app exporta el archivo usando el selector de documentos.

## Fuentes técnicas
- https://learn.microsoft.com/minecraft/creator/reference/content/addonsreference/packmanifest
- https://learn.microsoft.com/minecraft/creator/documents/minecraftfileextensions
