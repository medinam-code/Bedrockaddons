package org.bedrockforgeai

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class PackGeneratorTest {
    @Test fun generatedAddonContainsBothManifests() {
        val p = PackGenerator.generate(ProjectConfig("Test", "desc", PackKind.ADDON))
        assertNotNull(p.resourceManifestPath)
        assertNotNull(p.behaviorManifestPath)
        assertTrue(p.files.containsKey(p.resourceManifestPath))
        assertTrue(p.files.containsKey(p.behaviorManifestPath))
    }

    @Test fun manifestsHaveUniqueUuidsAndRequiredFields() {
        val p = PackGenerator.generate(ProjectConfig("Test", "desc", PackKind.ADDON))
        val rp = JSONObject(p.files[p.resourceManifestPath]!!.toString(Charsets.UTF_8))
        val bp = JSONObject(p.files[p.behaviorManifestPath]!!.toString(Charsets.UTF_8))
        assertNotEquals(rp.getJSONObject("header").getString("uuid"), bp.getJSONObject("header").getString("uuid"))
        assertEquals(2, rp.getInt("format_version"))
        assertEquals("resources", rp.getJSONArray("modules").getJSONObject(0).getString("type"))
        assertEquals("data", bp.getJSONArray("modules").getJSONObject(0).getString("type"))
    }

    @Test fun generatedProjectPassesBasicValidation() {
        val p = PackGenerator.generate(ProjectConfig("Test", "desc", PackKind.ADDON))
        assertFalse(PackValidator.validate(p.files).any { it.severity == ValidationIssue.Severity.ERROR })
    }

    @Test(expected = IllegalArgumentException::class)
    fun blankNameIsRejected() {
        PackGenerator.generate(ProjectConfig(" ", "desc", PackKind.RESOURCE))
    }
}
