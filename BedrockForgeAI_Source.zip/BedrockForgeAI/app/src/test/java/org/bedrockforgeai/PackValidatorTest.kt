package org.bedrockforgeai

import org.junit.Assert.*
import org.junit.Test

class PackValidatorTest {
    @Test fun emptyProjectReportsError() {
        assertTrue(PackValidator.validate(emptyMap()).any { it.severity == ValidationIssue.Severity.ERROR })
    }

    @Test fun invalidJsonIsReported() {
        val issues = PackValidator.validate(mapOf("manifest.json" to "{oops".toByteArray()))
        assertTrue(issues.any { it.severity == ValidationIssue.Severity.ERROR })
    }
}
