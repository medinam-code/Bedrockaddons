package org.bedrockforgeai

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.util.UUID

object PackValidator {
    fun validate(files: Map<String, ByteArray>): List<ValidationIssue> {
        val issues = mutableListOf<ValidationIssue>()
        if (files.isEmpty()) {
            return listOf(ValidationIssue(ValidationIssue.Severity.ERROR, "/", "El proyecto está vacío."))
        }
        val manifests = files.filterKeys { it.substringAfterLast('/') == "manifest.json" }
        if (manifests.isEmpty()) {
            issues += ValidationIssue(ValidationIssue.Severity.ERROR, "manifest.json", "No se encontró ningún manifiesto.")
        }

        val uuids = mutableSetOf<String>()
        manifests.forEach { (path, raw) ->
            try {
                val root = JSONObject(raw.toString(Charsets.UTF_8))
                if (root.optInt("format_version", -1) != 2) {
                    issues += error(path, "format_version debe ser 2 para este generador.")
                }
                val header = root.optJSONObject("header")
                if (header == null) {
                    issues += error(path, "Falta el objeto header.")
                } else {
                    if (header.optString("name").isBlank()) issues += error(path, "header.name está vacío.")
                    if (header.optString("description").isBlank()) issues += warning(path, "header.description está vacío.")
                    validateUuid(header.optString("uuid"), "$path header.uuid", uuids, issues)
                    validateVersion(header.optJSONArray("version"), "$path header.version", issues)
                    validateVersion(header.optJSONArray("min_engine_version"), "$path header.min_engine_version", issues)
                }
                val modules = root.optJSONArray("modules")
                if (modules == null || modules.length() == 0) {
                    issues += error(path, "Debe existir al menos un módulo.")
                } else {
                    for (i in 0 until modules.length()) {
                        val module = modules.optJSONObject(i)
                        if (module == null) {
                            issues += error(path, "El módulo $i no es un objeto.")
                            continue
                        }
                        val type = module.optString("type")
                        if (type !in setOf("resources", "data", "script", "world_template", "client_data")) {
                            issues += warning(path, "Tipo de módulo '$type' no reconocido por este validador.")
                        }
                        validateUuid(module.optString("uuid"), "$path modules[$i].uuid", uuids, issues)
                        validateVersion(module.optJSONArray("version"), "$path modules[$i].version", issues)
                    }
                }
            } catch (_: JSONException) {
                issues += error(path, "JSON inválido.")
            }
        }
        files.filterKeys { it.endsWith(".json", true) }.forEach { (path, raw) ->
            try { JSONObject(raw.toString(Charsets.UTF_8)) }
            catch (_: Exception) {
                try { JSONArray(raw.toString(Charsets.UTF_8)) }
                catch (_: Exception) { issues += error(path, "El archivo no contiene JSON válido.") }
            }
        }
        if (issues.none { it.severity == ValidationIssue.Severity.ERROR }) {
            issues += ValidationIssue(ValidationIssue.Severity.INFO, "/", "Validación estructural básica completada. Prueba el paquete dentro de Minecraft.")
        }
        return issues
    }

    private fun validateUuid(value: String, path: String, seen: MutableSet<String>, issues: MutableList<ValidationIssue>) {
        try {
            val normalized = UUID.fromString(value).toString()
            if (!seen.add(normalized)) issues += error(path, "UUID duplicado: $normalized")
        } catch (_: Exception) { issues += error(path, "UUID ausente o inválido.") }
    }

    private fun validateVersion(array: JSONArray?, path: String, issues: MutableList<ValidationIssue>) {
        if (array == null || array.length() != 3 || (0..2).any { array.optInt(it, -1) < 0 }) {
            issues += error(path, "La versión debe ser un arreglo de tres enteros no negativos, por ejemplo [1,0,0].")
        }
    }

    private fun error(path: String, message: String) =
        ValidationIssue(ValidationIssue.Severity.ERROR, path, message)
    private fun warning(path: String, message: String) =
        ValidationIssue(ValidationIssue.Severity.WARNING, path, message)
}
