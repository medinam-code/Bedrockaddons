package org.bedrockforgeai

enum class PackKind(val label: String) {
    RESOURCE("Paquete de recursos"),
    BEHAVIOR("Paquete de comportamiento"),
    ADDON("Add-On (recursos + comportamiento)")
}

data class ProjectConfig(
    val name: String,
    val description: String,
    val kind: PackKind,
    val minEngineVersion: List<Int> = listOf(1, 20, 0),
    val version: List<Int> = listOf(1, 0, 0)
)

data class GeneratedProject(
    val displayName: String,
    val kind: PackKind,
    val files: Map<String, ByteArray>,
    val resourceManifestPath: String?,
    val behaviorManifestPath: String?
)

data class ValidationIssue(val severity: Severity, val path: String, val message: String) {
    enum class Severity { ERROR, WARNING, INFO }
}
