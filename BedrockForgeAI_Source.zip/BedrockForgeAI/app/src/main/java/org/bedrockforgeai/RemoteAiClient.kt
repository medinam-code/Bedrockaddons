package org.bedrockforgeai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Optional OpenAI-compatible chat-completions endpoint.
 * No account, API key, or provider is bundled. User must choose a public endpoint.
 */
object RemoteAiClient {
    suspend fun ask(endpoint: String, prompt: String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            require(endpoint.startsWith("https://")) { "Usa un endpoint HTTPS." }
            val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 12000
                readTimeout = 30000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
            val body = JSONObject()
                .put("model", "default")
                .put("messages", JSONArray()
                    .put(JSONObject().put("role", "system").put("content",
                        "Eres un asistente especializado en Add-Ons de Minecraft Bedrock. Usa solo formatos reales y advierte cuando algo dependa de la versión."))
                    .put(JSONObject().put("role", "user").put("content", prompt)))
                .toString()
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val response = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) error("El servicio respondió HTTP $code: ${response.take(300)}")
            val json = JSONObject(response)
            json.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")
                ?.optString("content")?.takeIf { it.isNotBlank() }
                ?: error("Respuesta no compatible. Se esperaba choices[0].message.content.")
        }.also { /* Result is returned without logging prompts or responses. */ }
    }
}
