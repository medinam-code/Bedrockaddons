package org.bedrockforgeai

import java.io.BufferedOutputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object ZipExporter {
    fun writeMcpack(project: GeneratedProject, output: OutputStream, target: PackKind) {
        val root = when (target) {
            PackKind.RESOURCE -> project.resourceManifestPath?.substringBeforeLast('/') 
            PackKind.BEHAVIOR -> project.behaviorManifestPath?.substringBeforeLast('/')
            PackKind.ADDON -> null
        } ?: throw IllegalArgumentException("El proyecto no contiene ese tipo de paquete.")
        writeZip(output, project.files.filterKeys { it.startsWith("$root/") }
            .mapKeys { (path, _) -> path.removePrefix("$root/") })
    }

    fun writeMcaddon(project: GeneratedProject, output: OutputStream) {
        require(project.resourceManifestPath != null || project.behaviorManifestPath != null)
        val selected = linkedMapOf<String, ByteArray>()
        listOfNotNull(project.resourceManifestPath, project.behaviorManifestPath).forEach { manifestPath ->
            val root = manifestPath.substringBeforeLast('/')
            val packFiles = project.files.filterKeys { it.startsWith("$root/") }
            val innerBytes = zipToBytes(packFiles.mapKeys { (path, _) -> path.removePrefix("$root/") })
            selected["${root}.mcpack"] = innerBytes
        }
        writeZip(output, selected)
    }

    fun writeProjectZip(project: GeneratedProject, output: OutputStream) {
        writeZip(output, project.files)
    }

    private fun zipToBytes(files: Map<String, ByteArray>): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        writeZip(out, files)
        return out.toByteArray()
    }

    private fun writeZip(output: OutputStream, files: Map<String, ByteArray>) {
        ZipOutputStream(BufferedOutputStream(output)).use { zip ->
            files.toSortedMap().forEach { (path, bytes) ->
                val entry = ZipEntry(path.replace("\\", "/"))
                zip.putNextEntry(entry)
                zip.write(bytes)
                zip.closeEntry()
            }
        }
    }
}
