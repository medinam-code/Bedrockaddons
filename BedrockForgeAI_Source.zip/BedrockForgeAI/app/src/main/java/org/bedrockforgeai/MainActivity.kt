package org.bedrockforgeai

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BedrockForgeApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BedrockForgeApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var projectName by remember { mutableStateOf("Mi primer Add-On") }
    var description by remember { mutableStateOf("Creado con Bedrock Forge AI") }
    var kind by remember { mutableStateOf(PackKind.ADDON) }
    var versionText by remember { mutableStateOf("1.21.0") }
    var project by remember { mutableStateOf<GeneratedProject?>(null) }
    var manifestEditor by remember { mutableStateOf("") }
    var report by remember { mutableStateOf("Crea un proyecto para comenzar.") }
    var endpoint by remember { mutableStateOf("") }
    var aiPrompt by remember { mutableStateOf("Quiero crear una criatura amistosa para Minecraft Bedrock.") }
    var aiResponse by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var showAiSettings by remember { mutableStateOf(false) }
    var selectedColor by remember { mutableIntStateOf(android.graphics.Color.BLUE) }
    var pixels by remember { mutableStateOf(List(256) { android.graphics.Color.TRANSPARENT }) }

    val saveMcaddon = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri: Uri? ->
        if (uri != null) runCatching {
            val p = project ?: error("Primero genera un proyecto.")
            context.contentResolver.openOutputStream(uri)!!.use { ZipExporter.writeMcaddon(p, it) }
            report = "Exportación .mcaddon completada. Ábrela con Minecraft si Android ofrece esa opción."
        }.onFailure { report = "Error al exportar: ${it.message}" }
    }
    val saveRp = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri: Uri? ->
        if (uri != null) runCatching {
            val p = project ?: error("Primero genera un proyecto.")
            context.contentResolver.openOutputStream(uri)!!.use { ZipExporter.writeMcpack(p, it, PackKind.RESOURCE) }
            report = "Resource Pack .mcpack exportado."
        }.onFailure { report = "Error al exportar: ${it.message}" }
    }
    val saveBp = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri: Uri? ->
        if (uri != null) runCatching {
            val p = project ?: error("Primero genera un proyecto.")
            context.contentResolver.openOutputStream(uri)!!.use { ZipExporter.writeMcpack(p, it, PackKind.BEHAVIOR) }
            report = "Behavior Pack .mcpack exportado."
        }.onFailure { report = "Error al exportar: ${it.message}" }
    }
    val saveProject = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri: Uri? ->
        if (uri != null) runCatching {
            val p = project ?: error("Primero genera un proyecto.")
            context.contentResolver.openOutputStream(uri)!!.use { ZipExporter.writeProjectZip(p, it) }
            report = "Proyecto ZIP exportado para editarlo o compartirlo."
        }.onFailure { report = "Error al exportar: ${it.message}" }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = androidx.compose.ui.graphics.Color(0xFF75D5B1),
        secondary = androidx.compose.ui.graphics.Color(0xFF8DB7FF)
    )) {
        Scaffold(
            topBar = { TopAppBar(title = { Text("Bedrock Forge AI") }, actions = {
                TextButton(onClick = { showAiSettings = !showAiSettings }) { Text("IA") }
            }) }
        ) { padding ->
            Column(
                modifier = Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Creador de Add-Ons", style = MaterialTheme.typography.headlineSmall)
                Text("Sin cuenta · Generación local · Exportación para Bedrock")
                OutlinedTextField(projectName, { projectName = it }, label = { Text("Nombre del proyecto") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(description, { description = it }, label = { Text("Descripción") }, modifier = Modifier.fillMaxWidth())
                Text("Tipo de proyecto", style = MaterialTheme.typography.titleMedium)
                PackKind.values().forEach { option ->
                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        RadioButton(selected = kind == option, onClick = { kind = option })
                        Text(option.label)
                    }
                }
                OutlinedTextField(
                    versionText, { versionText = it },
                    label = { Text("Versión mínima Bedrock (mayor.menor.revisión)") },
                    supportingText = { Text("Ejemplo: 1.21.0. Comprueba el valor según el juego instalado.") },
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = {
                        runCatching {
                            val v = versionText.trim().split(".").map { it.toInt() }
                            require(v.size == 3 && v.all { it >= 0 }) { "Usa tres números, por ejemplo 1.21.0." }
                            val generated = PackGenerator.generate(ProjectConfig(projectName, description, kind, v))
                            project = generated
                            val manifestPath = generated.resourceManifestPath ?: generated.behaviorManifestPath
                            manifestEditor = manifestPath?.let { generated.files[it]?.toString(Charsets.UTF_8) } ?: ""
                            val results = PackValidator.validate(generated.files)
                            report = results.joinToString("\n") { "${it.severity}: ${it.path} — ${it.message}" }
                        }.onFailure { report = "No se pudo crear el proyecto: ${it.message}" }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Crear / regenerar proyecto") }

                project?.let { p ->
                    Text("Proyecto: ${p.displayName}", style = MaterialTheme.typography.titleMedium)
                    Text("Archivos generados: ${p.files.size}")
                    OutlinedTextField(
                        manifestEditor, { manifestEditor = it },
                        label = { Text("Editor JSON del manifiesto principal") },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 180.dp),
                        minLines = 6
                    )
                    Button(onClick = {
                        val current = project ?: return@Button
                        val path = current.resourceManifestPath ?: current.behaviorManifestPath ?: return@Button
                        val changed = current.files.toMutableMap()
                        changed[path] = manifestEditor.toByteArray(Charsets.UTF_8)
                        project = current.copy(files = changed)
                        val results = PackValidator.validate(changed)
                        report = results.joinToString("\n") { "${it.severity}: ${it.path} — ${it.message}" }
                    }, modifier = Modifier.fillMaxWidth()) { Text("Guardar JSON y validar") }
                    Button(onClick = { report = PackValidator.validate(p.files).joinToString("\n") { "${it.severity}: ${it.path} — ${it.message}" } }, modifier = Modifier.fillMaxWidth()) { Text("Validar proyecto") }
                    Button(onClick = { saveMcaddon.launch("${p.displayName}.mcaddon") }, modifier = Modifier.fillMaxWidth()) { Text("Exportar .mcaddon") }
                    if (p.resourceManifestPath != null) Button(onClick = { saveRp.launch("${p.displayName}_RP.mcpack") }, modifier = Modifier.fillMaxWidth()) { Text("Exportar Resource Pack .mcpack") }
                    if (p.behaviorManifestPath != null) Button(onClick = { saveBp.launch("${p.displayName}_BP.mcpack") }, modifier = Modifier.fillMaxWidth()) { Text("Exportar Behavior Pack .mcpack") }
                    Button(onClick = { saveProject.launch("${p.displayName}_project.zip") }, modifier = Modifier.fillMaxWidth()) { Text("Exportar proyecto editable .zip") }

                    HorizontalDivider()
                    Text("Editor de textura 16 × 16", style = MaterialTheme.typography.titleMedium)
                    Text("Toca una celda para pintarla. Guarda un PNG básico en el Resource Pack.")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(
                            android.graphics.Color.TRANSPARENT,
                            android.graphics.Color.WHITE,
                            android.graphics.Color.BLACK,
                            android.graphics.Color.BLUE,
                            android.graphics.Color.CYAN,
                            android.graphics.Color.MAGENTA,
                            android.graphics.Color.GREEN,
                            android.graphics.Color.RED,
                            android.graphics.Color.YELLOW
                        ).forEach { swatch ->
                            Box(
                                Modifier.size(28.dp)
                                    .background(Color(swatch))
                                    .border(1.dp, MaterialTheme.colorScheme.outline)
                                    .padding(0.dp)
                            ) {
                                Surface(
                                    modifier = Modifier.fillMaxSize(),
                                    color = Color(swatch),
                                    onClick = { selectedColor = swatch }
                                ) {}
                            }
                        }
                    }
                    Canvas(
                        modifier = Modifier.fillMaxWidth().aspectRatio(1f)
                            .border(1.dp, MaterialTheme.colorScheme.outline)
                            .pointerInput(selectedColor, pixels) {
                                detectTapGestures { offset ->
                                    val cell = size.width / 16f
                                    val x = (offset.x / cell).toInt().coerceIn(0, 15)
                                    val y = (offset.y / cell).toInt().coerceIn(0, 15)
                                    val mutable = pixels.toMutableList()
                                    mutable[y * 16 + x] = selectedColor
                                    pixels = mutable
                                }
                            }
                    ) {
                        val cellW = size.width / 16f
                        val cellH = size.height / 16f
                        pixels.forEachIndexed { index, colorInt ->
                            val x = index % 16
                            val y = index / 16
                            drawRect(
                                color = Color(colorInt),
                                topLeft = Offset(x * cellW, y * cellH),
                                size = androidx.compose.ui.geometry.Size(cellW, cellH)
                            )
                        }
                        for (i in 0..16) {
                            drawLine(Color.Gray.copy(alpha = 0.45f), Offset(i * cellW, 0f), Offset(i * cellW, size.height), 1f)
                            drawLine(Color.Gray.copy(alpha = 0.45f), Offset(0f, i * cellH), Offset(size.width, i * cellH), 1f)
                        }
                    }
                    Button(onClick = {
                        runCatching {
                            val current = project ?: error("Crea un proyecto primero.")
                            val root = current.resourceManifestPath?.substringBeforeLast('/')
                                ?: error("El editor de textura necesita un Resource Pack. Elige Add-On o Paquete de recursos.")
                            val updated = current.files.toMutableMap()
                            updated["$root/textures/entity/custom_texture.png"] = TextureEditor.png(pixels)
                            project = current.copy(files = updated)
                            report = "Textura PNG guardada dentro del proyecto. Recuerda crear la entidad/cliente que la referencie."
                        }.onFailure { report = "No se pudo guardar la textura: ${it.message}" }
                    }, modifier = Modifier.fillMaxWidth()) { Text("Guardar textura PNG en el proyecto") }
                }

                if (showAiSettings) {
                    HorizontalDivider()
                    Text("Asistencia de IA opcional", style = MaterialTheme.typography.titleLarge)
                    Text("No requiere cuenta en la app. Debes introducir un endpoint HTTPS público compatible que acepte solicitudes sin autenticación. No hay proveedor preconfigurado.")
                    OutlinedTextField(endpoint, { endpoint = it }, label = { Text("Endpoint HTTPS de chat completions") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(aiPrompt, { aiPrompt = it }, label = { Text("Qué quieres crear") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                    Button(enabled = !busy, onClick = {
                        busy = true
                        scope.launch {
                            val result = RemoteAiClient.ask(endpoint.trim(), aiPrompt)
                            aiResponse = result.getOrElse { "Error de IA: ${it.message}" }
                            busy = false
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "Consultando..." else "Consultar IA") }
                    if (aiResponse.isNotBlank()) {
                        Text("Respuesta", style = MaterialTheme.typography.titleMedium)
                        Text(aiResponse)
                    }
                }

                HorizontalDivider()
                Text("Informe", style = MaterialTheme.typography.titleMedium)
                Text(report)
                Text("La validación es estructural. Prueba cada Add-On en Minecraft Bedrock; no se garantiza compatibilidad de cada componente solo por validar el JSON.",
                    style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
