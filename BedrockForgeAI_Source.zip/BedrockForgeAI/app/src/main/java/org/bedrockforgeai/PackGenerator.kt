package org.bedrockforgeai

import org.json.JSONArray
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.util.UUID

object PackGenerator {
    private fun uuid() = UUID.randomUUID().toString()
    private fun bytes(s: String) = s.toByteArray(StandardCharsets.UTF_8)
    private fun versionArray(v: List<Int>) = JSONArray().apply { v.forEach { put(it) } }

    private fun manifest(name: String, description: String, type: String, minVersion: List<Int>): String {
        val headerUuid = uuid()
        val moduleUuid = uuid()
        val header = JSONObject()
            .put("name", name)
            .put("description", description)
            .put("uuid", headerUuid)
            .put("version", versionArray(listOf(1, 0, 0)))
            .put("min_engine_version", versionArray(minVersion))
        val module = JSONObject()
            .put("type", type)
            .put("uuid", moduleUuid)
            .put("version", versionArray(listOf(1, 0, 0)))
        val root = JSONObject()
            .put("format_version", 2)
            .put("header", header)
            .put("modules", JSONArray().put(module))
            .put("metadata", JSONObject()
                .put("authors", JSONArray().put("Bedrock Forge AI"))
                .put("license", "MIT")
                .put("generated_with", JSONObject().put("bedrock_forge_ai", JSONArray().put("0.1.0"))))
        return root.toString(2)
    }

    fun generate(config: ProjectConfig): GeneratedProject {
        require(config.name.isNotBlank()) { "El nombre del proyecto no puede estar vacío." }
        require(config.minEngineVersion.size == 3 && config.minEngineVersion.all { it >= 0 }) {
            "La versión mínima debe tener tres números no negativos."
        }
        require(config.version.size == 3 && config.version.all { it >= 0 }) {
            "La versión del paquete debe tener tres números no negativos."
        }

        val safeName = config.name.trim().replace(Regex("[^A-Za-z0-9._ -]"), "").ifBlank { "MiAddon" }
        val out = linkedMapOf<String, ByteArray>()
        var rpPath: String? = null
        var bpPath: String? = null

        if (config.kind == PackKind.RESOURCE || config.kind == PackKind.ADDON) {
            val folder = "${safeName}_RP"
            rpPath = "$folder/manifest.json"
            out[rpPath] = bytes(manifest("$safeName Resources", config.description, "resources", config.minEngineVersion))
            out["$folder/pack_icon.png"] = MinimalPng.create(128, 128)
            out["$folder/textures/README.txt"] = bytes(
                "Coloca aquí las texturas PNG de tu Resource Pack.\\n" +
                "Para entidades personalizadas también necesitarás geometría, render controllers y archivos de cliente válidos para Bedrock.\\n"
            )
            out["$folder/textures/terrain_texture.json"] = bytes(
                JSONObject().put("resource_pack_name", safeName).put("texture_name", "atlas.terrain")
                    .put("padding", 8).put("num_mip_levels", 4)
                    .put("texture_data", JSONObject()).toString(2)
            )
        }

        if (config.kind == PackKind.BEHAVIOR || config.kind == PackKind.ADDON) {
            val folder = "${safeName}_BP"
            bpPath = "$folder/manifest.json"
            out[bpPath] = bytes(manifest("$safeName Behavior", config.description, "data", config.minEngineVersion))
            out["$folder/pack_icon.png"] = MinimalPng.create(128, 128)
            out["$folder/entities/README.txt"] = bytes(
                "Coloca aquí archivos de entidades Bedrock con format_version y componentes compatibles con tu versión.\\n"
            )
            out["$folder/functions/README.txt"] = bytes(
                "Las funciones de comandos usan archivos .mcfunction. Revisa las reglas de sintaxis de tu versión de Bedrock.\\n"
            )
        }

        // For export we also create a root project descriptor; it is removed from individual pack exports.
        out["bedrock-forge-project.json"] = bytes(JSONObject()
            .put("generator", "Bedrock Forge AI")
            .put("generator_version", "0.1.0")
            .put("name", safeName)
            .put("kind", config.kind.name)
            .put("description", config.description)
            .toString(2))

        return GeneratedProject(safeName, config.kind, out, rpPath, bpPath)
    }
}

/** Tiny valid PNG generator for a neutral placeholder pack icon. */
private object MinimalPng {
    fun create(width: Int, height: Int): ByteArray {
        // A compact embedded 1x1 transparent PNG. Minecraft accepts PNG; dimensions are kept minimal in MVP.
        val encoded = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/lS8AAAAASUVORK5CYII="
        return java.util.Base64.getDecoder().decode(encoded)
    }
}
