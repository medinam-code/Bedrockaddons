package org.bedrockforgeai

import android.graphics.Bitmap
import java.io.ByteArrayOutputStream

object TextureEditor {
    fun png(pixels: List<Int>, size: Int = 16): ByteArray {
        require(size in 1..128) { "Tamaño de textura no válido." }
        require(pixels.size == size * size) { "La cuadrícula debe tener ${size * size} píxeles." }
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        bitmap.setPixels(pixels.toIntArray(), 0, size, 0, 0, size, size)
        val output = ByteArrayOutputStream()
        check(bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)) { "No se pudo codificar PNG." }
        bitmap.recycle()
        return output.toByteArray()
    }
}
